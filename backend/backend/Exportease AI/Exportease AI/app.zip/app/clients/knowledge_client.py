# ============================================================
# ExportEase AI - Knowledge Service Client (System 2)
# EXPORT-EASE-BACKEND-V1
# ============================================================
"""
Real HTTP client for System 2 (Knowledge / RAG).
System 3 normally must not access Qdrant directly.
For evidence/source operations, communicate through the Knowledge API.
Never import Qdrant implementation details into this backend.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from app.clients.base_client import BaseServiceClient

logger = logging.getLogger(__name__)


class KnowledgeServiceClient(BaseServiceClient):
    """Client for the Knowledge/RAG system (System 2)."""

    def __init__(self, base_url: str, timeout: int = 60, api_version: str = "v1"):
        super().__init__(
            base_url=base_url,
            timeout=timeout,
            api_version=api_version,
            service_name="Knowledge Service (System 2)",
        )
        self.api_prefix = f"/api/{api_version}"

    async def search_sources(
        self,
        query: str,
        project_id: str,
        filters: Optional[dict[str, Any]] = None,
        top_k: int = 10,
    ) -> dict[str, Any]:
        """Search the knowledge base for relevant sources."""
        return await self._post(
            f"{self.api_prefix}/knowledge/search",
            {
                "query": query,
                "project_id": project_id,
                "filters": filters or {},
                "top_k": top_k,
            },
        )

    async def get_source(self, source_id: str) -> dict[str, Any]:
        """Retrieve a specific source by ID."""
        return await self._get(f"{self.api_prefix}/knowledge/sources/{source_id}")

    async def verify_source(
        self, source_id: str, chunk_id: Optional[str] = None
    ) -> dict[str, Any]:
        """Verify a source from the knowledge base."""
        return await self._post(
            f"{self.api_prefix}/knowledge/verify",
            {"source_id": source_id, "chunk_id": chunk_id},
        )

    async def get_citations(
        self, source_ids: list[str]
    ) -> dict[str, Any]:
        """Retrieve citation details for given source IDs."""
        return await self._post(
            f"{self.api_prefix}/knowledge/citations",
            {"source_ids": source_ids},
        )

    async def get_regulatory_sources(
        self,
        country: str,
        hs_code: Optional[str] = None,
        topic: Optional[str] = None,
    ) -> dict[str, Any]:
        """Get regulatory sources for a specific country and product."""
        return await self._post(
            f"{self.api_prefix}/knowledge/regulatory",
            {
                "country": country,
                "hs_code": hs_code,
                "topic": topic,
            },
        )
