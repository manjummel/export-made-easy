# ============================================================
# ExportEase AI - Product Service
# EXPORT-EASE-BACKEND-V1
# ============================================================
import json
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.models.product import Product
from app.models.business import Business
from app.models.msme_profile import MSMEProfile
from app.schemas.product import ProductCreate, ProductUpdate
from app.utils.validators import generate_uuid
from app.clients.ai_client import AIClient
from app.clients.knowledge_client import KnowledgeClient


class ProductService:
    """Service handling product state and AI analysis integration."""
    
    @staticmethod
    async def create_product(db: AsyncSession, request: ProductCreate, user_id: str) -> Product:
        # Verify ownership mapping Business -> MSMEProfile -> User
        stmt = select(Business).join(MSMEProfile).where(
            Business.id == request.business_id,
            MSMEProfile.user_id == user_id
        )
        business = (await db.execute(stmt)).scalar_one_or_none()
        if not business:
            raise ValueError("Business not found or unauthorized")

        prod = Product(
            id=generate_uuid(),
            **request.model_dump()
        )
        db.add(prod)
        await db.flush()
        return prod

    @staticmethod
    async def get_product(db: AsyncSession, product_id: str, user_id: str) -> Product | None:
        stmt = select(Product).join(Business).join(MSMEProfile).where(
            Product.id == product_id,
            MSMEProfile.user_id == user_id
        )
        return (await db.execute(stmt)).scalar_one_or_none()
        
    @staticmethod
    async def list_products(db: AsyncSession, business_id: str, user_id: str) -> List[Product]:
        stmt = select(Product).join(Business).join(MSMEProfile).where(
            Product.business_id == business_id,
            MSMEProfile.user_id == user_id
        )
        return list((await db.execute(stmt)).scalars().all())

    @staticmethod
    async def update_product(db: AsyncSession, product_id: str, update: ProductUpdate, user_id: str) -> Product:
        product = await ProductService.get_product(db, product_id, user_id)
        if not product:
            raise ValueError("Product not found")
            
        update_data = update.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(product, key, value)
            
        await db.flush()
        return product
        
    @staticmethod
    async def delete_product(db: AsyncSession, product_id: str, user_id: str) -> None:
        product = await ProductService.get_product(db, product_id, user_id)
        if not product:
            raise ValueError("Product not found")
        await db.delete(product)
        await db.flush()

    @staticmethod
    async def analyze_product(db: AsyncSession, product_id: str, user_id: str) -> Product:
        """
        Executes System 1 AI and System 2 RAG evaluation to normalize and map HS parameters.
        Does not invent regulatory codes.
        """
        product = await ProductService.get_product(db, product_id, user_id)
        if not product:
            raise ValueError("Product not found")
            
        # Standard workflow dependency execution against System 1 and System 2
        ai_client = AIClient.get_instance()
        knowledge_client = KnowledgeClient.get_instance()
        
        # Pull definitions using Knowledge Service
        rag_context = await knowledge_client.search_regulations(
            query=f"HS classification definition {product.product_name}",
            category="CUSTOMS"
        )
        
        # Analyze parameters via AI Agent passing RAG contexts
        analysis = await ai_client.execute_classification(
            product_desc=product.product_name,
            context=str(rag_context.get("sources", []))
        )
        
        # Apply strict data limits
        if analysis["status"] == "success":
            data = analysis["data"]
            product.normalized_name = data.get("normalized_name", product.product_name)
            product.hs_code = data.get("hs_code")
            product.hs_description = data.get("description")
            product.hs_classification_confidence = analysis.get("confidence", 0.0)
            product.hs_classification_source = "AI_VERIFIED"
            product.attributes = json.dumps(data.get("attributes", {}))
            await db.flush()
            
        return product
